"""
dllsymbols - extract all symbols from an .obj file
           - works with DIGITAL Visual Fortran 6.0
Usage: python dllsymbols.py proj.obj [proj.def]
"""

import sys, os

def main(args):
    if not args:
        print __doc__
        return
    #
    try:
        file = os.popen('dumpbin -symbols '+args[0])
    except:
        print "Couldn't open file"
        return
    #
    symbols = []
    #
    for line in file.readlines():
        list = line.split()
        if 'External' in list and '@' in list[-1]:
            symbols.append(list[-1])
    file.close()
    #
    #
    # Write definition file
    projName = os.path.splitext(args[0])[0]
    try:
        file = open(args[1],'w')
    except:
        filename = projName+'.def'
        file = open(filename,'w')
    #
    file.write('LIBRARY '+projName.upper()+'.DLL\n\n')
    file.write('EXPORTS\n')
    for symbol in symbols:
        file.write('\t'+symbol+'\n')
    #
    file.close()


if __name__=='__main__':
    main(sys.argv[1:])
    