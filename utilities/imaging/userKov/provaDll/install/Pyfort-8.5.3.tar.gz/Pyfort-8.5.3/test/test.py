from Numeric import *
from Precision import *
from testpyf import *
def row_major(x):
    "Same shape but row-major order for data."
    return reshape(transpose(x), shape(x))

x0 = array([1,2,3])
y0 = x0 + 1
n = len(x0)
print "itimes", x0, y0
print itimes(x0, y0, n)
x=array([1,2,3], Float64)
y = x + 1.
print "times", x, y
print times(x, y, n)
r=1.2
ra=arange(10)
c = array([3., 4+2.0j])
print "bang", r, ra, c
print bang(r, ra,  10, n, c)

a = array([1.,2.,3.,4.,5.,6.], Float32)
a.shape=(2,3)
b = arange(12)*1.0
b.shape=(3,4)
print "a"
print a
print "b"
print b
print "sarg('yes')", sarg('yes')
print "copy1(ravel(a))"
print copy1(ravel(a))

print "two returns"
print two(row_major(a), 2, 3, 4, row_major(b), 0)
print "two with transpose option returns"
print two(a, 2, 3, 4, b)
print "two with list args and row_major"
al = list(a)
bl = list(b)
print two(row_major(al), 2, 3, 4, row_major(bl), 0)

print "two with mirror option returns"
a1=transpose(a)
b1=transpose(b)
r, c = two(a1, 2, 3, 4, b1, 2)
print (r, transpose(c))

print "copy2(a)"
acopy = copy2(a)
print acopy
print "Again, but using result of previous as input."
print copy2(acopy)

print "copy2(a) with mirror option"
TRANSPOSE_OPTION = 1
MIRROR_OPTION = 2
set_pyfort_option (MIRROR_OPTION)
acopy = copy2(a)
print acopy
print "Again, but using result of previous as input."
print copy2(acopy)
set_pyfort_option (TRANSPOSE_OPTION)

ca = x + 1.0j
c = 1 + 4j
print "c, ca", c, ca
print "ctest(c, ca) = ", ctest(c, ca)

inout1 = array([1,2,3,4])
print "inout1"
print inout1
print "inoutme(4, inout1), inout1 after call should be doubled:"
inoutme(4, inout1)
print inout1

print "nocheck result should be 11"
# Note, lengths not checked by nocheck, modify carefully!
temp = arange(9)
temp.shape = (3,3)
print nocheck(4, arange(4), temp)

print "work array example, should be near zero"
print work(arange(100))

print "mirror example, should look like output from two."
print mirror(a, 4, 3, 2, b, MIRROR)

c = chartest("x")
if c == "y": print "chartest 1 passed."
else: print "chartest 1 failed."
c = chartest("w")
if c == "n": print "chartest 2 passed."
else: print "chartest 2 failed."
