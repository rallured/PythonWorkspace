
def detect_fortran_compiler(full_path=True):

  import os,sys

  fortrans = """
g77
gfortran
f90
f95
g95
xlf90
fort77
pgf77
pgf90
cf77
xlf
ghf77
"""
  if os.environ.get('FC',None) is not None:
	print os.environ['FC']
	sys.exit()

  for f in fortrans.split():
	c,t=os.popen4('which '+f)
	t=t.readlines()
	if not 'no' in t[0].lower().split():
		if full_path :
			return t[0].strip()
		else:
			return f

if __name__=="__main__":
  print detect_fortran_compiler()
