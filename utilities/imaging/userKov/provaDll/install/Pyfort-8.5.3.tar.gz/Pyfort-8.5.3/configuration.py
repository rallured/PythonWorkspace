# Edit this file to change the defaults if desired.
# For Windows, may need to fix location of Visual Studio.

# A. Default compiler
import sys, os
try:
   import detect_fortran
   default_compiler=detect_fortran.detect_fortran_compiler(full_path=False)
   print default_compiler
except:
  default_compiler = 'g77'
  if sys.platform[0:5] == 'linux':
      PGI = os.environ.get('PGI', None)
      if PGI:
          default_compiler = 'pgf77'
  elif sys.platform == "sunos5":
      default_compiler = 'solaris'
  elif sys.platform == "win32":
      default_compiler = 'vf'
      vfroot = r'C:\Program Files\Microsoft Visual Studio\DF98'
  elif sys.platform[0:4] == "osf1":
      default_compiler = 'f77_OSF1'
  elif sys.platform[0:4] == 'irix':
      default_compiler = 'sgi'
  elif sys.platform[0:6] == 'darwin':
      import platform
      rel=int(platform.release().split('.')[0])
      if rel<8:
          default_compiler = 'macg77'
      else:
          default_compiler = "gfortran"
# B. Set the suffix used for project directories
# This is added to the project name to produce the container directory
# for the modules in the project. It is added to the Python path with a 
# .pth file of the same name. 
project_suffix = "_dir"

# C. Set the directory where Pyfort itself was installed if not the default.
#    You may wish to set project_suffix='' in this case; see README.
prefix=''


