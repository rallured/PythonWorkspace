#!/usr/bin/env python
import sys
from distutils.core import setup
name = 'Pyfort'
description = 'Python - Fortran Connection Tool'
execfile('version.py')
author = 'Paul F. Dubois, PCMDI, LLNL'
author_email = 'dubois@users.sourceforge.net'
url = 'http://pyfortran.sourceforge.net'
directory = '.'
package_list = [name]     
package_directories = {name: directory}
if sys.platform == 'win32':
    f = open('pyfort.bat', 'w')
    f.write("""\
%s -c "import sys; import Pyfort.driver;Pyfort.driver.run(sys.argv[1:])" %%* """ % sys.executable)
    f.close()
    script = 'pyfort.bat'
else:
    f = open('pyfort', 'w')
    f.write("""\
#!/bin/csh -f
exec %s -c "import sys; import Pyfort.driver;Pyfort.driver.run(sys.argv[1:])" $*
""" % sys.executable)
    f.close()
    script = 'pyfort'

setup (
       name = name,
       version = version,
       description = description,
       author = author,
       author_email = author_email,
       url = url,
       packages = package_list,
       package_dir = package_directories,
       scripts = [script]
       )
print "Pyfort Version", version
