#include <math.h>
#include <string.h>

double doit(double x) {
  return sqrt(x);
}

void itimes(int x[], int y[], int n, int w[]) {
  int i;
  for (i = 0; i < n; i++)
    w[i] = x[i] * y[i];
  return;
}

void dtimes(double x[], double y[], int n, double w[]) {
  int i;
  for (i = 0; i < n; i++)
    w[i] = x[i] * y[i];
  return;
}

float two (int n, int m, int k, float a[n][m], float b[m][k], float c[n][m]) {
  float result = 0.0;
  int i, j;
  for (i = 0; i < m; i++) result += b[i][0];
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
       c[i][j] = a[i][j];
  return result;
}

float atwo (int n, int m, int k, float** a, float** b, float** c) {
  float result = 0.0;
  int i, j;
  for (i = 0; i < m; i++) result += b[i][0];
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
       c[i][j] = a[i][j];
  return result;
}

void copy2 (int n, int m, float a[n][m], float c[n][m]) {
  int i, j;
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
       c[i][j] = a[i][j]; 
  return;
}

void copy1 (float a[], int n, float c[]) {
  int i;
  for (i = 0; i < n; i++) c[i] = a[i];
  return;
}

void no_return() {
  return;
}

int sarg (char* s, int* x)
{ int result;
  if(strcmp(s,"yes"))
    result = 0;
  else
    result = 1;
  *x = strlen(s);
  return result;
}

void inoutme (int n, int m[]) {
  int i;
  for (i = 0; i < n; i++)
     m[i] = 2 * m[i];
  return;
}

int nocheck (int n, int m[], int z[][3]) {
  int result = m[n-1] + z[2][2];
  return result;
}

float work (int n, float x[], int ly, float y[]) {
  float result; 
  int i;
  for (i = 0; i < n; i++) {
    y[i] = x[i];
    y[n+i] = -x[i];
  }
  result = 0.0;
  for (i = 0; i < ly; i++)
    result += y[i];
  return result;
}

float awork2d (int n, int m, float** x, int ny, int my, float** y) {
  float result; 
  int i,j;
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++) {
      y[i][j] = x[i][j];
      y[i][m+j] = -x[i][j];
      y[n+i][j] = -x[i][j];
      y[n+i][m+j] = x[i][j];
  }
  result = 0.0;
  for (i = 0; i < ny; i++)
    for (j = 0; j < my; j++)
      result += y[i][j];
  return result;

}
char chartest (char c) {
  if (c=='x')
    return 'y';
  else
    return 'n';
}

double ctry(int n, double* x, double* y) 
{
    int i;
    double d;
    d = 0.0;
    for (i=0; i < n; ++i) {
        d += x[i] * y[i];
    }
    return d;
}

void cout(int n, double* x, double* y) 
{
    int i;
    for (i = 0; i < n; ++i) {
        y[i] = 1.414159 * x[i];
    }
}

double c2(int n, int m, double x[n][m]) {
    double sum = 0.0;
    int i, j;
    for (i=0; i < n; i++) {
        for (j=0; j < m; j++) {
            sum += x[i][j];
        }
    }
    return sum;
}
    
double ac2(int n, int m, double** x) {
    double sum = 0.0;
    int i, j;
    for (i=0; i < n; i++) {
        for (j=0; j < m; j++) {
            sum += x[i][j];
        }
    }
    return sum;
}
    
double c3(float a) {
    return (double) a;
}

void acopy2 (int n, int m, float** a, float** c) {
  int i, j;
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
       c[i][j] = a[i][j]; 
  return;
}

void acopy3 (int n, int m, int p, float*** a, float*** c) {
  int i, j, k;
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
      for (k = 0; k < p; k++)
        c[i][j][k] = a[i][j][k]; 
  return;
}

void acopy4 (int n, int m, int p, int q, float**** a, float**** c) {
  int i, j, k, l;
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
      for (k = 0; k < p; k++)
        for (l = 0; l < q; l++)
          c[i][j][k][l] = a[i][j][k][l];
  return;
}
