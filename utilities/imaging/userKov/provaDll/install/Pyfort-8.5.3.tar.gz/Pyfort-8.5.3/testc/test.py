from Numeric import *
from Precision import *
from testc import *

x0 = array([1,2,3])
y0 = x0 + 1
n = len(x0)
print "itimes", x0, y0
print itimes(x0, y0, n)
x=array([1,2,3], Float64)
y = x + 1.
print "dtimes", x, y
print dtimes(x, y, n)

a = array([1.,2.,3.,4.,5.,6.], Float32)
a.shape=(2,3)
b = arange(12)*1.0
b.shape=(3,4)
print "a"
print a
print "b"
print b
print "sarg('yes')", sarg('yes')
print "should be (1, 3)"
print "copy1(ravel(a))"
print copy1(ravel(a))

print "two returns"
print two(2, 3, 4, a, b)
print "two with list args and row_major"
al = list(a)
bl = list(b)
print two(2, 3, 4, al, bl)
print "two using allocatable arrays"
print atwo(2, 3, 4, a, b)
print

print "copy2(a)"
acopy = copy2(a)
print acopy
print "Again, but using result of previous as input."
print copy2(acopy)

print "allocatable array test: acopy2(a)"
acopy = acopy2(a)
print acopy
print "Again, but using result of previous as input."
print acopy2(acopy)

print
a = arange(12.)
a.shape = (3,2,2)
print "a =", a
print "allocatable array test: acopy3(a)"
acopy = acopy3(a)
print acopy
print "Should be same as a"
print "Again, but using result of previous as input."
print acopy3(acopy)
print "Should be same as a"

print
a = arange(60.)
a.shape = (3,2,5,2)
print "a =", a
print "allocatable array test: acopy4(a)"
acopy = acopy4(a)
print acopy
print "Should be same as a"
print "Again, but using result of previous as input."
print acopy4(acopy)
print "Should be same as a"

print
inout1 = array([1,2,3,4])
print "inout1"
print inout1
print "inoutme(4, inout1), inout1 after call should be doubled:"
inoutme(4, inout1)
print inout1
print

print "nocheck result should be 11"
# Note, lengths not checked by nocheck, modify carefully!
temp = arange(9)
temp.shape = (3,3)
print nocheck(4, arange(4), temp)
print

print "work array example, should be near zero"
temp = arange(100)
print work(temp)
print "work array example in 2D with allocatable arrays, should be near zero"
temp.shape = (10,10)
print awork2d(temp)

x = array([1.,2.,3.])
y = array([6.,-1.,-1.])
z = arange(6) *1.0
z.shape=(3,2)
print "Should be 1.0:", ctry(x,y)
print "Should be sqrt(2) * [1,2,3]:", cout(x)
print "Should be 15.0:", c2(z)
print "Same test, with allocatable arrays. Should be 15.0:", ac2(z)
z.shape=(2,3)
print "Should be 15.0:", c2(z)
print "Same test, with allocatable arrays. Should be 15.0:", ac2(z)
w = c3 (12.0)
if w != 12.0: print "c3 test failed."

c = chartest("x")
if c == "y": print "chartest 1 passed."
else: print "chartest 1 failed."
c = chartest("w")
if c == "n": print "chartest 2 passed."
else: print "chartest 2 failed."
