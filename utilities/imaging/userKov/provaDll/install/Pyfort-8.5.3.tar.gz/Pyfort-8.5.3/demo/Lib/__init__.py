import Numeric
import pyfdemo

def percentile (d, x):
    "Return percentile of observation d among sample x"
    y = Numeric.array(x, copy=0)
    z = Numeric.sort(y)
    return pyfdemo.percentile(d, z)

