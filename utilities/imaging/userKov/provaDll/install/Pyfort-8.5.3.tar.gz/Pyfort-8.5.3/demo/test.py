from RNG import CreateGenerator, NormalDistribution
import pyfdemo

if __name__ == '__main__':
    print "Example 1: using a list."
    x = [5.,6.,7.,8.,1.,2.,3.,4.]
    print "x=", x
    print "percentile of 2.3 in x is", pyfdemo.percentile(2.3, x)
    print
    print "Example 2: using a distribution"
    nd = CreateGenerator(-1, NormalDistribution(10., 2.))
    x = nd.sample(100000)
    print "percentile of 10.0 in normal(10.,2) is", pyfdemo.percentile(10.0, x)

